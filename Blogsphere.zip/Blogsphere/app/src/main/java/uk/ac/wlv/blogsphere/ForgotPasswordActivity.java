package uk.ac.wlv.blogsphere;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordActivity extends AppCompatActivity {

    EditText usernameInput;
    Button retrieveBtn;
    TextView result;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        usernameInput = findViewById(R.id.usernameInput);
        retrieveBtn = findViewById(R.id.retrieveBtn);
        result = findViewById(R.id.resultText);
        dbHelper = new DBHelper(this);

        retrieveBtn.setOnClickListener(v -> {
            String uname = usernameInput.getText().toString().trim();
            if (uname.isEmpty()) {
                Toast.makeText(this, "Enter your username", Toast.LENGTH_SHORT).show();
            } else {
                String password = dbHelper.getPasswordByUsername(uname);
                if (password != null) {
                    result.setText("Your password is: " + password);
                } else {
                    result.setText("No user found with that username.");
                }
            }
        });
    }
}
