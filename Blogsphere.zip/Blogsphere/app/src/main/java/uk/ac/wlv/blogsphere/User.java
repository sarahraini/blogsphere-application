package uk.ac.wlv.blogsphere;

public class User {
    public String firstName, username, email, password;

    public User(String firstName, String username, String email, String password) {
        this.firstName = firstName;
        this.username = username;
        this.email = email;
        this.password = password;
    }
}
