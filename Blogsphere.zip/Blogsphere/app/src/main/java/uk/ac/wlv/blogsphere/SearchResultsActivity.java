package uk.ac.wlv.blogsphere;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SearchResultsActivity extends AppCompatActivity {

    RecyclerView resultRecyclerView;
    PostAdapter postAdapter;
    DBHelper dbHelper;
    List<PostModel> filteredPosts;
    TextView resultCount;
    EditText searchInput;
    ImageView backButton, clearButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        // Init views
        resultRecyclerView = findViewById(R.id.resultRecyclerView);
        resultCount = findViewById(R.id.resultCountText);
        searchInput = findViewById(R.id.searchInput);
        backButton = findViewById(R.id.backButton);
        clearButton = findViewById(R.id.clearButton);

        resultRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        filteredPosts = new ArrayList<>();

        postAdapter = new PostAdapter(filteredPosts);
        resultRecyclerView.setAdapter(postAdapter);

        // Get initial query
        String query = getIntent().getStringExtra("query");
        searchInput.setText(query);
        filterPosts(query); // initial filter

        // TextWatcher to live filter as user types
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterPosts(s.toString());
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

        backButton.setOnClickListener(v -> finish());
        clearButton.setOnClickListener(v -> searchInput.setText(""));
    }

    private void filterPosts(String keyword) {
        List<PostModel> allPosts = dbHelper.getAllPosts();
        filteredPosts.clear();

        for (PostModel post : allPosts) {
            if (post.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                    post.getContent().toLowerCase().contains(keyword.toLowerCase())) {
                filteredPosts.add(post);
            }
        }

        resultCount.setText(filteredPosts.size() + " results found");
        postAdapter.notifyDataSetChanged();

    }
}
