package uk.ac.wlv.blogsphere;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "blogsphere.db";

    public DBHelper(Context context) {
        super(context, "BlogSphereDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "firstName TEXT, " +
                "username TEXT, " +
                "email TEXT UNIQUE, " +
                "password TEXT)");

        db.execSQL("CREATE TABLE posts(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, " +
                "content TEXT, " +
                "image BLOB, " +
                "created_at TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS posts");
        onCreate(db);
    }

    //  Method to insert post
    public boolean insertPost(String title, String content, byte[] imageBytes, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("title", title);
        values.put("content", content);
        values.put("image", imageBytes);
        values.put("created_at", date);

        long result = db.insert("posts", null, values);
        return result != -1;
    }

    public boolean registerUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("firstName", user.firstName);
        values.put("username", user.username);
        values.put("email", user.email);
        values.put("password", user.password);
        long result = db.insert("users", null, values);
        return result != -1;
    }

    public boolean isEmailRegistered(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email = ?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean updatePassword(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("password", newPassword);
        int result = db.update("users", values, "username = ?", new String[]{username});
        return result > 0;
    }

    public boolean checkUserLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        boolean isLoggedIn = cursor.getCount() > 0;
        cursor.close();
        return isLoggedIn;
    }
    public List<PostModel> getAllPosts() {
        List<PostModel> postList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM posts ORDER BY id DESC", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String content = cursor.getString(cursor.getColumnIndexOrThrow("content"));
                byte[] image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("created_at"));

                PostModel post = new PostModel(id, title, content, image, date);
                postList.add(post);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return postList;
    }

    public String getPasswordByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT password FROM users WHERE username = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            String pwd = cursor.getString(0);
            cursor.close();
            return pwd;
        }
        cursor.close();
        return null;
    }


    public void deletePost(int postId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("posts", "id = ?", new String[]{String.valueOf(postId)});
    }

    public boolean updatePost(int id, String title, String content, byte[] image) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("content", content);
        values.put("image", image);

        int rows = db.update("posts", values, "id = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public PostModel getPostById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM posts WHERE id = ?", new String[]{String.valueOf(id)});

        PostModel post = null;

        if (cursor.moveToFirst()) {
            String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
            String content = cursor.getString(cursor.getColumnIndexOrThrow("content"));
            byte[] image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("created_at"));

            post = new PostModel(id, title, content, image, date);
        }

        cursor.close();
        return post;
    }


}
