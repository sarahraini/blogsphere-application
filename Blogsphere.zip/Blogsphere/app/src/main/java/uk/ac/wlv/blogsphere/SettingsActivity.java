package uk.ac.wlv.blogsphere;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;

public class SettingsActivity extends AppCompatActivity {

    TextView platformDisplay, usernameDisplay;
    EditText newPassword, confirmPassword;
    Button changePasswordBtn;

    SwitchCompat darkModeSwitch, saveImagesSwitch, autoSyncSwitch;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Toolbar setup
        Toolbar toolbar = findViewById(R.id.settingsToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Settings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Account detail views
        platformDisplay = findViewById(R.id.platformDisplay);
        usernameDisplay = findViewById(R.id.usernameDisplay);
        newPassword = findViewById(R.id.newPassword);
        confirmPassword = findViewById(R.id.confirmPassword);
        changePasswordBtn = findViewById(R.id.changePasswordBtn);

        // Retrieve username from intent
        username = getIntent().getStringExtra("username");
        String platform = "Blogger"; // Static for now

        platformDisplay.setText(platform);
        usernameDisplay.setText(username != null ? username : "your_username");

        // Preference switches
        darkModeSwitch = findViewById(R.id.darkModeSwitch);
        saveImagesSwitch = findViewById(R.id.saveImagesSwitch);
        autoSyncSwitch = findViewById(R.id.autoSyncSwitch);

        preferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        editor = preferences.edit();

        // Load saved preferences
        darkModeSwitch.setChecked(preferences.getBoolean("darkMode", false));
        saveImagesSwitch.setChecked(preferences.getBoolean("saveImages", false));
        autoSyncSwitch.setChecked(preferences.getBoolean("autoSync", true));

        // Save preference changes
        darkModeSwitch.setOnCheckedChangeListener((CompoundButton buttonView, boolean isChecked) -> {
            editor.putBoolean("darkMode", isChecked);
            editor.apply();
            Toast.makeText(this, isChecked ? "Dark mode enabled" : "Dark mode disabled", Toast.LENGTH_SHORT).show();
        });

        saveImagesSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            editor.putBoolean("saveImages", isChecked);
            editor.apply();
            Toast.makeText(this, isChecked ? "Save images ON" : "Save images OFF", Toast.LENGTH_SHORT).show();
        });

        autoSyncSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            editor.putBoolean("autoSync", isChecked);
            editor.apply();
            Toast.makeText(this, isChecked ? "Auto-sync ON" : "Auto-sync OFF", Toast.LENGTH_SHORT).show();
        });

        // Change Password Logic
        changePasswordBtn.setOnClickListener(v -> {
            String newPass = newPassword.getText().toString().trim();
            String confirmPass = confirmPassword.getText().toString().trim();

            if (newPass.isEmpty() || confirmPass.isEmpty()) {
                Toast.makeText(this, "Please enter both password fields", Toast.LENGTH_SHORT).show();
            } else if (!newPass.equals(confirmPass)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                DBHelper dbHelper = new DBHelper(this);
                boolean updated = dbHelper.updatePassword(username, newPass);
                if (updated) {
                    Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                    newPassword.setText("");
                    confirmPassword.setText("");
                } else {
                    Toast.makeText(this, "Password update failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
