package uk.ac.wlv.blogsphere;

public class PostModel {
    private int id;
    private String title;
    private String content;
    private byte[] image;
    private String createdAt;

    // Full constructor with ID
    public PostModel(int id, String title, String content, byte[] image, String createdAt) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.image = image;
        this.createdAt = createdAt;
    }

    // Optional: constructor without ID (for inserting new posts)
    public PostModel(String title, String content, byte[] image, String createdAt) {
        this.title = title;
        this.content = content;
        this.image = image;
        this.createdAt = createdAt;
    }

    // Getter and Setter for ID
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Other getters
    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public byte[] getImage() {
        return image;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    // Optional setters (if needed)
    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
