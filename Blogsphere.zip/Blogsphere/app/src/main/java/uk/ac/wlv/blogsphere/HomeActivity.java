package uk.ac.wlv.blogsphere;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import uk.ac.wlv.blogsphere.LoginActivity;
import uk.ac.wlv.blogsphere.SettingsActivity;

public class HomeActivity extends AppCompatActivity {

    TextView createPostText;
    FloatingActionButton fab;
    Toolbar toolbar;
    String username;

    RecyclerView postRecyclerView;
    PostAdapter postAdapter;
    DBHelper dbHelper;
    List<PostModel> postList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Username from intent
        username = getIntent().getStringExtra("username");

        // Toolbar setup
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("BlogSphere");

        // RecyclerView setup
        postRecyclerView = findViewById(R.id.postRecyclerView);
        postRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        postList = new ArrayList<>();
        postAdapter = new PostAdapter(postList);
        postRecyclerView.setAdapter(postAdapter);

        // FAB to open CreatePostActivity
        fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, CreatePostActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        createPostText = findViewById(R.id.createPostText);

        // Initial load
        loadPosts();
    }

    private void loadPosts() {
        postList.clear();
        postList.addAll(dbHelper.getAllPosts());
        postAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPosts(); // Refresh when returning from CreatePostActivity
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_search) {
            Intent intent = new Intent(this, SearchResultsActivity.class);
            intent.putExtra("query", ""); // Optional: start empty
            startActivity(intent);
            return true;
        }

        if (id == R.id.menu_profile) {
            Intent intent = new Intent(this, AccountActivity.class);
            intent.putExtra("username", getIntent().getStringExtra("username"));
            startActivity(intent);
            return true;
        }

        if (id == R.id.menu_settings) {
            Intent settingsIntent = new Intent(this, SettingsActivity.class);
            settingsIntent.putExtra("username", username);
            startActivity(settingsIntent);
            return true;
        }
        if (id == R.id.menu_logout) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}