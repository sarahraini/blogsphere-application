package uk.ac.wlv.blogsphere;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import uk.ac.wlv.blogsphere.R;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    private final List<PostModel> postList;

    public PostAdapter(List<PostModel> postList) {
        this.postList = postList;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        PostModel post = postList.get(position);
        holder.title.setText(post.getTitle());
        holder.content.setText(post.getContent());

        if (post.getImage() != null) {
            Bitmap bmp = BitmapFactory.decodeByteArray(post.getImage(), 0, post.getImage().length);
            holder.image.setImageBitmap(bmp);
        }

        holder.date.setText(getTimeAgo(post.getCreatedAt()));

        // Share icon click handler
        holder.shareIcon.setOnClickListener(v -> {
            Bitmap bmp = null;
            if (post.getImage() != null) {
                bmp = BitmapFactory.decodeByteArray(post.getImage(), 0, post.getImage().length);
            }

            if (bmp != null) {
                try {
                    // Save image temporarily to cache
                    File cachePath = new File(v.getContext().getCacheDir(), "images");
                    cachePath.mkdirs();
                    File file = new File(cachePath, "shared_image.png");
                    FileOutputStream stream = new FileOutputStream(file);
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    stream.close();

                    Uri imageUri = FileProvider.getUriForFile(
                            v.getContext(),
                            v.getContext().getPackageName() + ".provider", // You must match authority in manifest
                            file
                    );

                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("image/*");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                    shareIntent.putExtra(Intent.EXTRA_TEXT, post.getTitle() + "\n\n" + post.getContent());
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    v.getContext().startActivity(Intent.createChooser(shareIntent, "Share post via"));

                } catch (Exception e) {
                    Toast.makeText(v.getContext(), "Failed to share image", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Share text only
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, post.getTitle() + "\n\n" + post.getContent());
                v.getContext().startActivity(Intent.createChooser(shareIntent, "Share post via"));
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), PostDetailsActivity.class);
            intent.putExtra("postId", post.getId());
            intent.putExtra("title", post.getTitle());
            intent.putExtra("content", post.getContent());
            intent.putExtra("createdAt", post.getCreatedAt());
            intent.putExtra("image", post.getImage());
            v.getContext().startActivity(intent);
        });

    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    // Helper method for formatting "time ago"
    private String getTimeAgo(String dateTimeStr) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Date postDate = format.parse(dateTimeStr);
            long now = System.currentTimeMillis();
            long time = postDate.getTime();

            long diff = now - time;
            long seconds = diff / 1000;
            long minutes = seconds / 60;
            long hours = minutes / 60;
            long days = hours / 24;

            if (seconds < 60) return "Just now";
            else if (minutes < 60) return minutes + "m ago";
            else if (hours < 24) return hours + "h ago";
            else return days + "d ago";

        } catch (Exception e) {
            return dateTimeStr; // fallback
        }
    }

    // ViewHolder
    static class PostViewHolder extends RecyclerView.ViewHolder {
        TextView title, content, date;
        ImageView image, shareIcon;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.postTitleText);
            content = itemView.findViewById(R.id.postContentText);
            date = itemView.findViewById(R.id.postDate);
            image = itemView.findViewById(R.id.postImage);
            shareIcon = itemView.findViewById(R.id.shareIcon); // ✅ added share icon reference
        }
    }
}