package uk.ac.wlv.blogsphere;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    EditText firstName, username, email, password, confirmPassword;
    Button signUpBtn;
    TextView loginRedirect;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize views
        firstName = findViewById(R.id.firstName);
        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        signUpBtn = findViewById(R.id.signUpBtn);
        loginRedirect = findViewById(R.id.loginRedirect);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        signUpBtn.setOnClickListener(v -> {
            String fName = firstName.getText().toString().trim();
            String uName = username.getText().toString().trim();
            String emailText = email.getText().toString().trim();
            String pwd = password.getText().toString();
            String cpwd = confirmPassword.getText().toString();

            // Input Validation
            if (fName.isEmpty() || uName.isEmpty() || emailText.isEmpty() || pwd.isEmpty() || cpwd.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            } else if (!isValidEmail(emailText)) {
                Toast.makeText(this, "Invalid email address", Toast.LENGTH_SHORT).show();
            } else if (!isValidPassword(pwd)) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            } else if (!pwd.equals(cpwd)) {
                Toast.makeText(this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.isEmailRegistered(emailText)) {
                Toast.makeText(this, "Email already registered!", Toast.LENGTH_SHORT).show();
            } else {
                // Store in SQLite
                User user = new User(fName, uName, emailText, pwd);
                if (dbHelper.registerUser(user)) {
                    Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show();
                    // Optionally clear fields or navigate to login
                } else {
                    Toast.makeText(this, "Registration failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loginRedirect.setOnClickListener(v -> {
            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Optional
        });
    }

    private boolean isValidEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isValidPassword(String password) {
        return password.length() >= 6;
    }
}
