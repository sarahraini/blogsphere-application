package uk.ac.wlv.blogsphere;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Utils {
    public static String getTimeAgo(String dateTimeStr) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Date postDate = format.parse(dateTimeStr);
            long now = System.currentTimeMillis();
            long time = postDate.getTime();
            long diff = now - time;

            long seconds = diff / 1000;
            long minutes = seconds / 60;
            long hours = minutes / 60;
            long days = hours / 24;

            if (seconds < 60) return "Just now";
            else if (minutes < 60) return minutes + " minutes ago";
            else if (hours < 24) return hours + " hours ago";
            else return days + " day" + (days > 1 ? "s" : "") + " ago";
        } catch (Exception e) {
            return dateTimeStr;
        }
    }
}
