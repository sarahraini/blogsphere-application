package uk.ac.wlv.blogsphere;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class PostDetailsActivity extends AppCompatActivity {

    ImageView postImage, editBtn, saveBtn, editImageBtn;
    EditText postTitle, postContent;
    TextView postTime;
    DBHelper dbHelper;
    int postId;
    String createdAt;
    byte[] imageBytes;
    static final int PICK_IMAGE = 101;

    boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_details);

        dbHelper = new DBHelper(this);

        Toolbar toolbar = findViewById(R.id.postDetailsToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Initialize UI
        postImage = findViewById(R.id.fullPostImage);
        postTitle = findViewById(R.id.fullPostTitle);
        postTime = findViewById(R.id.fullPostTime);
        postContent = findViewById(R.id.fullPostContent);
        editBtn = findViewById(R.id.editBtn);
        saveBtn = findViewById(R.id.saveBtn);
        editImageBtn = findViewById(R.id.editImageBtn);
        editImageBtn.setVisibility(View.GONE);

        // Get intent data
        Intent intent = getIntent();
        postId = intent.getIntExtra("postId", -1);
        String title = intent.getStringExtra("title");
        String content = intent.getStringExtra("content");
        createdAt = intent.getStringExtra("createdAt");
        imageBytes = intent.getByteArrayExtra("image");

        if (postId == -1) {
            Toast.makeText(this, "Invalid post data", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        postTitle.setText(title);
        postContent.setText(content);
        postTime.setText("Posted " + Utils.getTimeAgo(createdAt));

        if (imageBytes != null) {
            Bitmap bmp = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            postImage.setImageBitmap(bmp);
        }

        // View mode default
        postTitle.setEnabled(false);
        postContent.setEnabled(false);
        saveBtn.setVisibility(View.GONE);

        editBtn.setOnClickListener(v -> {
            isEditMode = true;
            postTitle.setEnabled(true);
            postContent.setEnabled(true);
            saveBtn.setVisibility(View.VISIBLE);
            editImageBtn.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Edit mode enabled", Toast.LENGTH_SHORT).show();
        });

        editImageBtn.setOnClickListener(v -> openImagePicker());

        saveBtn.setOnClickListener(v -> {
            String newTitle = postTitle.getText().toString().trim();
            String newContent = postContent.getText().toString().trim();

            if (newTitle.isEmpty() || newContent.isEmpty()) {
                Toast.makeText(this, "Title and content cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = dbHelper.updatePost(postId, newTitle, newContent, imageBytes);
            if (success) {
                Toast.makeText(this, "Post updated", Toast.LENGTH_SHORT).show();
                postTitle.setEnabled(false);
                postContent.setEnabled(false);
                saveBtn.setVisibility(View.GONE);
                editImageBtn.setVisibility(View.GONE);
                isEditMode = false;
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.deleteBtn).setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Post")
                    .setMessage("Are you sure you want to delete this post?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        dbHelper.deletePost(postId);
                        Toast.makeText(this, "Post deleted", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        findViewById(R.id.shareBtn).setOnClickListener(v -> showShareBottomSheet());
        findViewById(R.id.uploadBtn).setOnClickListener(v -> showUploadOptions());
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void showShareBottomSheet() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View view = getLayoutInflater().inflate(R.layout.layout_share_bottom_sheet, null);
        dialog.setContentView(view);

        view.findViewById(R.id.shareGmail).setOnClickListener(v -> {
            shareToSpecificApp("com.google.android.gm");
            dialog.dismiss();
        });
        view.findViewById(R.id.shareWhatsapp).setOnClickListener(v -> {
            shareToSpecificApp("com.whatsapp");
            dialog.dismiss();
        });
        view.findViewById(R.id.shareMessenger).setOnClickListener(v -> {
            shareToSpecificApp("com.facebook.orca");
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showUploadOptions() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View view = getLayoutInflater().inflate(R.layout.layout_social_upload, null);
        dialog.setContentView(view);

        view.findViewById(R.id.facebookShare).setOnClickListener(v -> {
            shareToSpecificApp("com.facebook.katana");
            dialog.dismiss();
        });
        view.findViewById(R.id.instagramShare).setOnClickListener(v -> {
            shareToSpecificApp("com.instagram.android");
            dialog.dismiss();
        });
        view.findViewById(R.id.twitterShare).setOnClickListener(v -> {
            shareToSpecificApp("com.twitter.android");
            dialog.dismiss();
        });

        dialog.show();
    }

    private void shareToSpecificApp(String packageName) {
        if (imageBytes == null) {
            Toast.makeText(this, "No image to share", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Save image temporarily
            File imageFile = new File(getCacheDir(), "shared_post.jpg");
            try (FileOutputStream fos = new FileOutputStream(imageFile)) {
                fos.write(imageBytes);
            }

            Uri imageUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".provider",
                    imageFile
            );

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("image/*");
            shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
            shareIntent.putExtra(Intent.EXTRA_TEXT,
                    postTitle.getText().toString().trim() + "\n\n" +
                            postContent.getText().toString().trim());
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            // Only set package if app is installed AND supports ACTION_SEND
            if (isAppInstalled(packageName)) {
                shareIntent.setPackage(packageName);
            }

            // Launch chooser
            startActivity(Intent.createChooser(shareIntent, "Share post via"));

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error sharing post", Toast.LENGTH_SHORT).show();
        }
    }


    private boolean isAppInstalled(String packageName) {
        try {
            getPackageManager().getApplicationInfo(packageName, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            try {
                Uri imageUri = data.getData();
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                postImage.setImageBitmap(bitmap);

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream);
                imageBytes = stream.toByteArray();

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Image load failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
