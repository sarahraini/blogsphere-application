package uk.ac.wlv.blogsphere;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AccountActivity extends AppCompatActivity {

    EditText editUsername, editEmail, editBio;
    ImageView profileImage;
    Button saveProfileBtn;
    SharedPreferences preferences;

    private static final int PICK_IMAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        Toolbar toolbar = findViewById(R.id.accountToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("My Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        preferences = getSharedPreferences("UserProfile", MODE_PRIVATE);

        editUsername = findViewById(R.id.editUsername);
        editEmail = findViewById(R.id.editEmail);
        editBio = findViewById(R.id.editBio);
        profileImage = findViewById(R.id.profileImage);
        saveProfileBtn = findViewById(R.id.saveProfileBtn);

        // Load saved values
        editUsername.setText(preferences.getString("username", ""));
        editEmail.setText(preferences.getString("email", ""));
        editBio.setText(preferences.getString("bio", ""));

        // TODO: Load saved image URI if needed

        saveProfileBtn.setOnClickListener(v -> {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("username", editUsername.getText().toString());
            editor.putString("email", editEmail.getText().toString());
            editor.putString("bio", editBio.getText().toString());
            editor.apply();
            Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show();
        });

        profileImage.setOnClickListener(v -> {
            Intent pickImageIntent = new Intent(Intent.ACTION_PICK);
            pickImageIntent.setType("image/*");
            startActivityForResult(pickImageIntent, PICK_IMAGE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            profileImage.setImageURI(imageUri);

            // Optionally store imageUri.toString() in SharedPreferences
            preferences.edit().putString("profileImageUri", imageUri.toString()).apply();
        }
    }
}
